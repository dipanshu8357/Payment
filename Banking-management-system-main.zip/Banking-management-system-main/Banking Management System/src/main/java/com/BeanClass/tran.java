package com.BeanClass;

public class tran {
	String customer_s,customer_r;
	int money;
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public String getCustomer_s() {
		return customer_s;
	}
	public void setCustomer_s(String customer_s) {
		this.customer_s = customer_s;
	}
	public String getCustomer_r() {
		return customer_r;
	}
	public void setCustomer_r(String customer_r) {
		this.customer_r = customer_r;
	}

	

}

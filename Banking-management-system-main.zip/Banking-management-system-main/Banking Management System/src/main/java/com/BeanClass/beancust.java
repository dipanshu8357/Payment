package com.BeanClass;

public class beancust {
int ac;
String name;
String Email;
int balance;
public int getAc() {
	return ac;
}
public void setAc(int ac) {
	this.ac = ac;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return Email;
}
public void setEmail(String email) {
	Email = email;
}
public int getBalance() {
	return balance;
}
public void setBalance(int balance) {
	this.balance = balance;
}

}

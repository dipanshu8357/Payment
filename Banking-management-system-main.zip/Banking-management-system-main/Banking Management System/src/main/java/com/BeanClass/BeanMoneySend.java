package com.BeanClass;

public class BeanMoneySend {

	private int sender,reciver,amtsend;

	public int getSender() {
		return sender;
	}

	public void setSender(int sender) {
		this.sender = sender;
	}

	public int getReciver() {
		return reciver;
	}

	public void setReciver(int reciver) {
		this.reciver = reciver;
	}

	public int getAmtsend() {
		return amtsend;
	}

	public void setAmtsend(int amtsend) {
		this.amtsend = amtsend;
	}
}
